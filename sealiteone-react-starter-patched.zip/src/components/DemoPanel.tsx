import React, { useState } from "react";
import axios from "axios";

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || "http://localhost:8000",
  withCredentials: true,
});

export default function DemoPanel() {
  const [log, setLog] = useState<string[]>([]);
  const [csrf, setCsrf] = useState("");

  const addLog = (msg: string) => setLog((l) => [...l, msg]);

  const login = async () => {
    try {
      const res = await api.post("/api/method/login", {
        usr: import.meta.env.VITE_DEMO_USER || "demo@example.com",
        pwd: import.meta.env.VITE_DEMO_PASS || "password",
      });
      addLog("Login: " + JSON.stringify(res.data));
      const csrfRes = await api.get("/api/method/frappe.client.get_csrf_token");
      setCsrf(csrfRes.data.message);
      addLog("Got CSRF: " + csrfRes.data.message);
    } catch (err: any) {
      addLog("Login error: " + err.toString());
    }
  };

  const whoami = async () => {
    try {
      const res = await api.get("/api/method/salitemiret.api.auth.whoami", {
        headers: { "X-Frappe-CSRF-Token": csrf },
      });
      addLog("Whoami: " + JSON.stringify(res.data));
    } catch (err: any) {
      addLog("Whoami error: " + err.toString());
    }
  };

  const createProcess = async () => {
    try {
      const res = await api.post(
        "/api/method/salitemiret.api.workflow.create_process",
        { title: "Onboard Volunteer" },
        { headers: { "X-Frappe-CSRF-Token": csrf } }
      );
      addLog("Created process: " + JSON.stringify(res.data));
    } catch (err: any) {
      addLog("Create process error: " + err.toString());
    }
  };

  return (
    <div style={{ padding: "1rem" }}>
      <h2>Demo Panel</h2>
      <button onClick={login}>Login</button>
      <button onClick={whoami}>Whoami</button>
      <button onClick={createProcess}>Create Workflow</button>
      <div style={{ marginTop: "1rem", whiteSpace: "pre-wrap" }}>
        {log.map((l, i) => (
          <div key={i}>{l}</div>
        ))}
      </div>
    </div>
  );
}
