# SealiteOne React Starter × Frappe Backend

## Quick Start

1. Copy `.env.example` to `.env` and set `VITE_API_URL` to your backend (local or Cloudflare tunnel).
2. Install deps and start dev server:
   npm i
   npm run dev

## What’s Included

- `src/api/client.ts`: Axios instance
- `src/api/auth.ts`: login/logout/whoami
- `src/api/workflow.ts`: createProcess/addStep/advance
- `src/components/DemoPanel.tsx`: Simple UI to exercise the APIs
- `src/App.tsx`: Renders `DemoPanel`

## Expected Backend

Frappe site with the `salitemiret` app and the following whitelisted methods available:

- `salitemiret.api.auth.whoami`
- `salitemiret.api.workflow.create_process`
- `salitemiret.api.workflow.add_step`
- `salitemiret.api.workflow.advance`

Make sure CORS is allowed for your frontend origin:
bench --site salitemiret.local set-config allow_cors '["http://localhost:5173","http://127.0.0.1:5173","https://<your-render-app>.onrender.com"]'
bench --site salitemiret.local clear-cache
