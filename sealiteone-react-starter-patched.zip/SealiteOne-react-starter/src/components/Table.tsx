
import { ReactNode } from 'react'
export function Table({columns, children}:{columns:ReactNode; children:ReactNode}){
  return (
    <table className="table">
      <thead><tr className="text-sm">{columns}</tr></thead>
      <tbody>{children}</tbody>
    </table>
  )
}
