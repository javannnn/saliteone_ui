
export function Badge({kind='default', children}:{kind?:'default'|'ok'|'warn'|'danger'; children:any}){
  const cls = { default:'badge', ok:'badge badge-ok', warn:'badge badge-warn', danger:'badge badge-danger' }[kind]
  return <span className={cls}>{children}</span>
}
