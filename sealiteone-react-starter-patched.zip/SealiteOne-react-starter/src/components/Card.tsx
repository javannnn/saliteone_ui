
import { ReactNode } from 'react'
export function Card({title, children}:{title?:string; children?:ReactNode}){
  return (
    <div className="card">
      {title && <h3 className="font-semibold mb-2">{title}</h3>}
      {children}
    </div>
  )
}
