
import { Link, NavLink, Outlet } from 'react-router-dom'
import logo from '@/assets/logo.svg'

function Topbar(){
  return (
    <div className="h-14 bg-white border-b border-slate-200 flex items-center px-3 gap-3">
      <Link to="/" className="flex items-center gap-2 font-extrabold">
        <img src={logo} alt="SealiteOne logo" className="w-5 h-5" />
        <div className="leading-tight">
          <div>SealiteOne</div>
          <div className="text-[11px] text-slate-500 font-semibold">Edmonton Se’alite Mihret St. Mary Church</div>
        </div>
      </Link>
      <div className="flex-1 max-w-xl ml-2 relative">
        <input className="input w-full pl-8" placeholder="Search members, invoices, services…" aria-label="Global search"/>
        <span className="absolute left-2 top-2.5 text-slate-500">🔎</span>
      </div>
      <Link to="/quick-add" className="btn" title="Quick Add">＋</Link>
      <Link to="/inbox" className="btn" title="Inbox">🔔</Link>
    </div>
  )
}

function Sidebar(){
  const Item = ({to, label}:{to:string; label:string}) => (
    <NavLink to={to} className={({isActive}) =>
      "block px-3 py-2 rounded-xl " + (isActive ? "bg-blue-50 border border-blue-200 text-blue-900" : "hover:bg-blue-50 hover:border hover:border-blue-100")
    }>{label}</NavLink>
  )
  return (
    <aside className="hidden md:block w-64 bg-white border-r border-slate-200 p-3">
      <div className="text-[11px] uppercase text-slate-500 font-semibold mb-2">Main</div>
      <Item to="/" label="Dashboard" />
      <Item to="/members" label="Members" />
      <Item to="/services" label="Services" />
      <Item to="/programs/sunday-school" label="Sunday School" />
      <Item to="/programs/abenet-school" label="Abenet School" />
      <Item to="/billing" label="Billing" />
      <Item to="/sponsorship" label="Sponsorship" />
      <Item to="/settlement" label="Settlement" />
      <Item to="/volunteers" label="Volunteers" />
      <Item to="/councils" label="Councils" />
      <Item to="/media" label="Media" />
      <Item to="/reports" label="Reports" />
      <div className="text-[11px] uppercase text-slate-500 font-semibold mt-3 mb-2">Admin</div>
      <Item to="/admin" label="Admin & Settings" />
      <Item to="/login" label="Logout" />
    </aside>
  )
}

export default function MainLayout(){
  return (
    <div className="min-h-screen grid grid-rows-[56px_1fr] md:grid-cols-[256px_1fr] md:grid-rows-[56px_1fr] bg-slate-50">
      <div className="md:col-span-2"><Topbar/></div>
      <Sidebar/>
      <main className="p-4 max-w-6xl mx-auto w-full"><Outlet/></main>
    </div>
  )
}
