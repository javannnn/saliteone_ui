import DemoPanel from "./components/DemoPanel";

function App() {
  return (
    <>
      <DemoPanel />
    </>
  );
}

export default App;
