import api from "./client";

export async function createProcess(title: string) {
  const { data } = await api.post("/api/method/salitemiret.api.workflow.create_process", { title });
  return data.message;
}

export async function addStep(process: string, step_name: string, order: number) {
  const { data } = await api.post("/api/method/salitemiret.api.workflow.add_step", {
    process, step_name, order
  });
  return data.message;
}

export async function advance(process: string, to_step: string) {
  const { data } = await api.post("/api/method/salitemiret.api.workflow.advance", {
    process, to_step
  });
  return data.message;
}
