import api from "./client";

export async function login(usr: string, pwd: string) {
  await api.post("/api/method/login", { usr, pwd });
  const { data } = await api.get("/api/method/frappe.client.get_csrf_token");
  api.defaults.headers.common["X-Frappe-CSRF-Token"] = data.message;
  return whoami();
}

export async function logout() {
  await api.post("/api/method/logout");
  delete api.defaults.headers.common["X-Frappe-CSRF-Token"];
}

export async function whoami() {
  const { data } = await api.get("/api/method/salitemiret.api.auth.whoami");
  return data.message;
}
