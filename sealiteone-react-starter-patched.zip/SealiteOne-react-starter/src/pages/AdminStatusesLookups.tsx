
import { useState } from 'react'
type Row = { category:'User Status'|'Membership Status'|'Service Status'; value:string }
export default function AdminStatusesLookups(){
  const [rows,setRows] = useState<Row[]>([
    { category:'User Status', value:'Admin' },
    { category:'User Status', value:'Active' },
    { category:'User Status', value:'Temporary' },
    { category:'User Status', value:'Pending' },
  ])
  const [form,setForm] = useState<Row>({ category:'User Status', value:'' })
  return (
    <div>
      <div className="text-sm text-slate-500 mb-1">Home › Admin › Statuses & Lookups</div>
      <h1 className="text-2xl font-extrabold mb-3">Statuses & Lookups</h1>
      <div className="card mb-3">
        <div className="grid md:grid-cols-2 gap-3">
          <div className="field"><label>Category</label><select className="select" value={form.category} onChange={e=>setForm({...form,category:e.target.value as any})}><option>User Status</option><option>Membership Status</option><option>Service Status</option></select></div>
          <div className="field"><label>Value</label><input className="input" value={form.value} onChange={e=>setForm({...form,value:e.target.value})}/></div>
        </div>
        <button className="btn btn-primary" onClick={()=>{ if(form.value) setRows([...rows,form]); setForm({ category:'User Status', value:'' }) }}>Add</button>
      </div>
      <table className="table"><thead><tr><th>Category</th><th>Value</th></tr></thead><tbody>{rows.map((r,i)=>(<tr key={i}><td>{r.category}</td><td>{r.value}</td></tr>))}</tbody></table>
    </div>
  )
}
