
export default function Receipts() {
  return (
    <div>
      <div className="text-sm text-slate-500 mb-1">Home › Billing › Receipts</div>
      <h1 className="text-2xl font-extrabold mb-3">Receipts</h1>

<table className="table">
  <thead><tr><th>#</th><th>Date</th><th>Member</th><th>Amount</th><th></th></tr></thead>
  <tbody><tr><td>R-8831</td><td>2025-08-03</td><td>Mary Smith</td><td>$75.00</td><td><a href="#">Download PDF</a></td></tr></tbody>
</table>

    </div>
  )
}
