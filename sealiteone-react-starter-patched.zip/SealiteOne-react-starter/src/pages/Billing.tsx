
export default function Billing() {
  return (
    <div>
      <div className="text-sm text-slate-500 mb-1">Home › Billing</div>
      <h1 className="text-2xl font-extrabold mb-3">Billing</h1>

<div className="grid md:grid-cols-3 gap-3">
  <div className="card"><h3 className="font-semibold mb-2">Invoices</h3><p>Create and manage invoices for membership, services, donations/tithe, programs, sponsorships.</p><a className="btn" href="/invoices">Open Invoices</a></div>
  <div className="card"><h3 className="font-semibold mb-2">Payments</h3><p>Record and review payments across all items.</p><a className="btn" href="/payments">Open Payments</a></div>
  <div className="card"><h3 className="font-semibold mb-2">Receipts</h3><p>Download official receipts.</p><a className="btn" href="/receipts">Open Receipts</a></div>
</div>

    </div>
  )
}
