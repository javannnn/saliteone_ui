
export default function Login() {
  return (
    <div>
      <div className="text-sm text-slate-500 mb-1">Welcome</div>
      <h1 className="text-2xl font-extrabold mb-3">Sign in</h1>

<div className="grid md:grid-cols-2 items-center max-w-5xl mx-auto p-4">
  <div className="card w-full">
    <h1 className="text-2xl font-extrabold mb-3">Sign in</h1>
    <div className="field"><label>Email</label><input className="input"/></div>
    <div className="field"><label>Password</label><input type="password" className="input"/></div>
    <div className="mt-2"><a className="btn btn-primary" href="/">Sign in</a></div>
  </div>
  <div className="card"><h3 className="font-semibold mb-2">About</h3><p>Role-based access for Members, Finance, Media, Office Admins.</p></div>
</div>

    </div>
  )
}
