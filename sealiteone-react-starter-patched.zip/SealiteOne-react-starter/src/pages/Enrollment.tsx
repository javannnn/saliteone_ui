
export default function Enrollment() {
  return (
    <div>
      <div className="text-sm text-slate-500 mb-1">Home › Programs › Enrollment</div>
      <h1 className="text-2xl font-extrabold mb-3">New Enrollment</h1>

<div className="grid md:grid-cols-2 gap-3">
  <div className="card">
    <div className="field"><label>Person</label><input className="input" placeholder="Search member or child"/></div>
    <div className="field"><label>Program</label><select className="select"><option>Sunday School</option><option>Abenet School</option></select></div>
    <div className="field"><label>Class / Track</label><input className="input" placeholder="e.g., Level 1, Reading"/></div>
    <div className="field"><label>Start Date</label><input type="date" className="input"/></div>
    <div className="field"><label>Monthly Fee</label><input className="input" defaultValue="25.00"/></div>
    <div><a className="btn btn-primary" href="/programs/sunday-school">Create Enrollment</a></div>
  </div>
  <div className="card"><h3 className="font-semibold mb-2">Billing</h3><div className="text-slate-500 text-sm">Recurring monthly invoices will be created after submission.</div></div>
</div>

    </div>
  )
}
