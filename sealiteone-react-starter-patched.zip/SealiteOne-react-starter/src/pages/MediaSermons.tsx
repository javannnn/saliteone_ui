
import { useState } from 'react'
type Row = { title:string; preacher:string; date:string; url:string; status:'Pending'|'Approved'|'Rejected' }
export default function MediaSermons(){
  const [rows,setRows] = useState<Row[]>([
    { title:'Psalm 23', preacher:'Fr. Mark', date:'2025-08-30', url:'https://example.com/sermon.mp3', status:'Pending' }
  ])
  const [form,setForm] = useState<Row>({ title:'', preacher:'', date:'', url:'', status:'Pending' })
  return (
    <div>
      <div className="text-sm text-slate-500 mb-1">Home › Media › Sermons</div>
      <h1 className="text-2xl font-extrabold mb-3">Sermons</h1>
      <div className="card mb-3">
        <div className="grid md:grid-cols-4 gap-3">
          <div className="field"><label>Title</label><input className="input" value={form.title} onChange={e=>setForm({...form,title:e.target.value})}/></div>
          <div className="field"><label>Preacher</label><input className="input" value={form.preacher} onChange={e=>setForm({...form,preacher:e.target.value})}/></div>
          <div className="field"><label>Date</label><input type="date" className="input" value={form.date} onChange={e=>setForm({...form,date:e.target.value})}/></div>
          <div className="field"><label>Media URL</label><input className="input" value={form.url} onChange={e=>setForm({...form,url:e.target.value})}/></div>
        </div>
        <div className="field"><label>Status</label><select className="select" value={form.status} onChange={e=>setForm({...form,status:e.target.value as any})}><option>Pending</option><option>Approved</option><option>Rejected</option></select></div>
        <button className="btn btn-primary" onClick={()=>{ if(form.title) setRows([...rows,form]); setForm({ title:'', preacher:'', date:'', url:'', status:'Pending' }) }}>Add Sermon</button>
      </div>
      <table className="table"><thead><tr><th>Title</th><th>Preacher</th><th>Date</th><th>Status</th><th>Link</th></tr></thead><tbody>{rows.map((r,i)=>(<tr key={i}><td>{r.title}</td><td>{r.preacher}</td><td>{r.date}</td><td><span className="badge">{r.status}</span></td><td><a href={r.url} target="_blank">Open</a></td></tr>))}</tbody></table>
    </div>
  )
}
