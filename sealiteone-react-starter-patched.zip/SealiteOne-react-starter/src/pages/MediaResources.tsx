
import { useState } from 'react'
type Row = { title:string; category:'Lesson'|'Guide'|'Form'|'Other'; url:string; status:'Pending'|'Approved'|'Rejected' }
export default function MediaResources(){
  const [rows,setRows] = useState<Row[]>([
    { title:'Volunteer Guide', category:'Guide', url:'https://example.com/guide.pdf', status:'Approved' }
  ])
  const [form,setForm] = useState<Row>({ title:'', category:'Lesson', url:'', status:'Pending' })
  return (
    <div>
      <div className="text-sm text-slate-500 mb-1">Home › Media › Resources</div>
      <h1 className="text-2xl font-extrabold mb-3">Resources</h1>
      <div className="card mb-3">
        <div className="grid md:grid-cols-3 gap-3">
          <div className="field"><label>Title</label><input className="input" value={form.title} onChange={e=>setForm({...form,title:e.target.value})}/></div>
          <div className="field"><label>Category</label><select className="select" value={form.category} onChange={e=>setForm({...form,category:e.target.value as any})}><option>Lesson</option><option>Guide</option><option>Form</option><option>Other</option></select></div>
          <div className="field"><label>File/URL</label><input className="input" value={form.url} onChange={e=>setForm({...form,url:e.target.value})}/></div>
        </div>
        <div className="field"><label>Status</label><select className="select" value={form.status} onChange={e=>setForm({...form,status:e.target.value as any})}><option>Pending</option><option>Approved</option><option>Rejected</option></select></div>
        <button className="btn btn-primary" onClick={()=>{ if(form.title) setRows([...rows,form]); setForm({ title:'', category:'Lesson', url:'', status:'Pending' }) }}>Add Resource</button>
      </div>
      <table className="table"><thead><tr><th>Title</th><th>Category</th><th>Status</th><th>Link</th></tr></thead><tbody>{rows.map((r,i)=>(<tr key={i}><td>{r.title}</td><td>{r.category}</td><td><span className="badge">{r.status}</span></td><td><a href={r.url} target="_blank">Open</a></td></tr>))}</tbody></table>
    </div>
  )
}
