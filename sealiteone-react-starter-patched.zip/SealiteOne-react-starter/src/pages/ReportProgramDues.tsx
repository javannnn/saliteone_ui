
import { useMemo, useState } from 'react'
import { Table } from '@/components/Table'
import { exportCsv } from '@/components/ExportCsv'

type Row = { program: 'Sunday School'|'Abenet School', name: string, classOrTrack: string, start: string, lastPayment: string, monthlyFee: number }

const data: Row[] = [
  { program: 'Sunday School', name: 'Michael Doe', classOrTrack: 'Child — Level 2', start: '2025-07-01', lastPayment: '2025-08-01', monthlyFee: 25 },
  { program: 'Abenet School', name: 'Sarah Tesfa', classOrTrack: 'Reading', start: '2025-06-01', lastPayment: '2025-08-01', monthlyFee: 25 },
]

export default function ReportProgramDues(){
  const [program, setProgram] = useState('')
  const [q, setQ] = useState('')

  const rows = useMemo(()=>{
    return data.filter(r => (program ? r.program === program as any : true) && (r.name + ' ' + r.classOrTrack).toLowerCase().includes(q.toLowerCase()))
  },[program,q])

  return (
    <div>
      <div className="text-sm text-slate-500 mb-1">Home › Reports › Program Dues</div>
      <h1 className="text-2xl font-extrabold mb-3">Program Dues</h1>
      <div className="flex gap-2 items-end mb-2">
        <div className="field"><label>Program</label><select className="select" value={program} onChange={e=>setProgram(e.target.value)}><option value="">All</option><option>Sunday School</option><option>Abenet School</option></select></div>
        <div className="field flex-1"><label>Search</label><input className="input" placeholder="Name or class/track" value={q} onChange={e=>setQ(e.target.value)} /></div>
        <button className="btn" onClick={()=>exportCsv('program-dues.csv', rows)}>Export CSV</button>
      </div>
      <Table columns={<><th>Program</th><th>Name</th><th>Class/Track</th><th>Start</th><th>Last Payment</th><th>Monthly Fee</th></>}>
        {rows.map((r,i)=>(
          <tr key={i}><td>{r.program}</td><td>{r.name}</td><td>{r.classOrTrack}</td><td>{r.start}</td><td>{r.lastPayment}</td><td>${r.monthlyFee.toFixed(2)}</td></tr>
        ))}
      </Table>
    </div>
  )
}
