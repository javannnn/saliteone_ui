
export default function Reports() {
  return (
    <div>
      <div className="text-sm text-slate-500 mb-1">Home › Reports</div>
      <h1 className="text-2xl font-extrabold mb-3">Reports</h1>

<div className="grid md:grid-cols-3 gap-3">
  <div className="card"><h3 className="font-semibold mb-2">Payments Report</h3><p>Filter by date, type, method.</p><a className="btn" href="#">Open</a></div>
  <div className="card"><h3 className="font-semibold mb-2">Program Dues</h3><p>Sunday/Abenet last payment date.</p><a className="btn" href="#">Open</a></div>
  <div className="card"><h3 className="font-semibold mb-2">Sponsorship</h3><p>Frequency, last date, status.</p><a className="btn" href="#">Open</a></div>
</div>

    </div>
  )
}
