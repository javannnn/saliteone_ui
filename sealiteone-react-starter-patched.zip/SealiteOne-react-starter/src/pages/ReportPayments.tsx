
import { useMemo, useState } from 'react'
import data from '@/data/payments.json'
import { Table } from '@/components/Table'
import { exportCsv } from '@/components/ExportCsv'

export default function ReportPayments(){
  const [from, setFrom] = useState('')
  const [to, setTo] = useState('')
  const [method, setMethod] = useState('')
  const [q, setQ] = useState('')

  const rows = useMemo(()=>{
    return data.filter(r => {
      const passQ = (r.member + ' ' + r.invoice).toLowerCase().includes(q.toLowerCase())
      const passMethod = method ? r.method === method : true
      const passFrom = from ? r.date >= from : true
      const passTo = to ? r.date <= to : true
      return passQ && passMethod && passFrom && passTo
    })
  },[q, method, from, to])

  return (
    <div>
      <div className="text-sm text-slate-500 mb-1">Home › Reports › Payments Report</div>
      <h1 className="text-2xl font-extrabold mb-3">Payments Report</h1>
      <div className="flex flex-wrap gap-2 items-end mb-2">
        <div className="field"><label>From</label><input type="date" className="input" value={from} onChange={e=>setFrom(e.target.value)} /></div>
        <div className="field"><label>To</label><input type="date" className="input" value={to} onChange={e=>setTo(e.target.value)} /></div>
        <div className="field"><label>Method</label><select className="select" value={method} onChange={e=>setMethod(e.target.value)}><option value="">All</option><option>Cash</option><option>Debit</option><option>Credit</option><option>e-transfer</option><option>Cheque</option></select></div>
        <div className="field flex-1"><label>Search</label><input className="input" placeholder="Member or Invoice" value={q} onChange={e=>setQ(e.target.value)} /></div>
        <button className="btn" onClick={()=>exportCsv('payments.csv', rows as any)}>Export CSV</button>
      </div>
      <Table columns={<><th>Date</th><th>Invoice</th><th>Member</th><th>Method</th><th>Amount</th></>}>
        {rows.map((r,i)=>(
          <tr key={i}><td>{r.date}</td><td>{r.invoice}</td><td>{r.member}</td><td>{r.method}</td><td>${r.amount.toFixed(2)}</td></tr>
        ))}
      </Table>
    </div>
  )
}
