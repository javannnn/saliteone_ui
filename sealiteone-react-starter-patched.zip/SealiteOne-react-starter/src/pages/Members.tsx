
import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { Table } from '@/components/Table'
import membersData from '@/data/members.json'
type Member = typeof membersData[number]

export default function Members(){
  const [q,setQ] = useState('')
  const [status,setStatus] = useState('')
  const [rows,setRows] = useState<Member[]>(membersData)

  useEffect(()=>{
    let r = membersData.filter(m => (m.firstName + ' ' + m.lastName + ' ' + m.email).toLowerCase().includes(q.toLowerCase()))
    if(status) r = r.filter(m => m.status === status)
    setRows(r)
  },[q,status])

  return (
    <div>
      <div className="text-sm text-slate-500 mb-1">Home › Members</div>
      <h1 className="text-2xl font-extrabold mb-3">Members</h1>
      <div className="flex gap-2 items-center mb-2">
        <Link className="btn btn-primary" to="/members/new">Add Member</Link>
        <div className="flex-1" />
        <input className="input" placeholder="Filter by name/email" value={q} onChange={e=>setQ(e.target.value)}/>
        <select className="select" value={status} onChange={e=>setStatus(e.target.value)}>
          <option value="">Status</option>
          <option>Active</option>
          <option>Pending</option>
          <option>Temporary</option>
        </select>
        <button className="btn">Export CSV</button>
      </div>
      <Table columns={<><th>Name</th><th>Username</th><th>Status</th><th>Email</th><th>Phone</th><th>Father Confessor</th><th></th></>}>
        {rows.map(m => (
          <tr key={m.id}>
            <td>{m.firstName} {m.lastName}</td>
            <td>{m.username}</td>
            <td><span className={m.status==='Active'?'badge badge-ok':'badge'}>{m.status}</span></td>
            <td>{m.email}</td>
            <td>{m.phone}</td>
            <td>{m.priest}</td>
            <td><Link to={`/members/${m.id}`}>View</Link></td>
          </tr>
        ))}
      </Table>
    </div>
  )
}
