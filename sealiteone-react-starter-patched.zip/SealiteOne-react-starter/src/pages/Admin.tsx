
export default function Admin() {
  return (
    <div>
      <div className="text-sm text-slate-500 mb-1">Home › Admin</div>
      <h1 className="text-2xl font-extrabold mb-3">Admin & Settings</h1>

<div className="grid md:grid-cols-3 gap-3">
  <div className="card"><h3 className="font-semibold mb-2">Users & Roles</h3><a className="btn" href="/admin/users-roles">Open</a></div>
  <div className="card"><h3 className="font-semibold mb-2">Priests (Father of Repentance)</h3><a className="btn" href="/admin/priests">Open</a></div>
  <div className="card"><h3 className="font-semibold mb-2">Service Types</h3><a className="btn" href="/admin/service-types">Open</a></div>
  <div className="card"><h3 className="font-semibold mb-2">Programs & Classes</h3><a className="btn" href="/admin/programs-classes">Open</a></div>
  <div className="card"><h3 className="font-semibold mb-2">Payment Methods</h3><a className="btn" href="/admin/payment-methods">Open</a></div>
  <div className="card"><h3 className="font-semibold mb-2">Statuses & Lookups</h3><a className="btn" href="/admin/statuses-lookups">Open</a></div>
  <div className="card"><h3 className="font-semibold mb-2">Email Templates</h3><a className="btn" href="/admin/email-templates">Open</a></div>
</div>

    </div>
  )
}
