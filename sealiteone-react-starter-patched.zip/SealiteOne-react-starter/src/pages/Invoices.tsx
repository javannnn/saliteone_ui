
export default function Invoices() {
  return (
    <div>
      <div className="text-sm text-slate-500 mb-1">Home › Billing › Invoices</div>
      <h1 className="text-2xl font-extrabold mb-3">Invoices</h1>

<div className="flex gap-2 items-center mb-2">
  <a className="btn btn-primary" href="/invoice-new">Create Invoice</a>
  <div className="flex-1" />
  <select className="select"><option>Type</option><option>Membership</option><option>Service</option><option>Sunday School</option><option>Abenet</option><option>Tithe</option><option>Donation</option><option>Sponsorship</option></select>
  <select className="select"><option>Status</option><option>Pending</option><option>Paid</option><option>Overdue</option></select>
</div>
<table className="table">
  <thead><tr><th>#</th><th>Member</th><th>Issued</th><th>Due</th><th>Status</th><th>Total</th><th></th></tr></thead>
  <tbody>
    <tr><td>INV-1028</td><td>John Doe</td><td>2025-08-01</td><td>2025-08-15</td><td><span className="badge badge-warn">Overdue</span></td><td>$120.00</td><td><a href="/invoices/INV-1028">View</a></td></tr>
  </tbody>
</table>

    </div>
  )
}
