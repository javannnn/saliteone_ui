
import { useState } from 'react'
type User = { name:string; email:string; role:string; active:boolean }
const initial: User[] = [
  { name:'Aman Getachew', email:'aman@example.com', role:'Super Admin', active:true },
  { name:'Fr. Mark', email:'fr.mark@example.com', role:'Media (Kahen)', active:true },
  { name:'Finance Clerk', email:'finance@example.com', role:'Finance', active:true },
]
export default function AdminUsersRoles(){
  const [users,setUsers] = useState<User[]>(initial)
  const [form,setForm] = useState<User>({ name:'', email:'', role:'Office Admin', active:true })
  function addUser(e:any){ e.preventDefault(); setUsers([...users, form]); setForm({ name:'', email:'', role:'Office Admin', active:true }) }
  return (
    <div>
      <div className="text-sm text-slate-500 mb-1">Home › Admin › Users & Roles</div>
      <h1 className="text-2xl font-extrabold mb-3">Users & Roles</h1>
      <form onSubmit={addUser} className="card mb-3">
        <div className="grid md:grid-cols-4 gap-3">
          <div className="field"><label>Name</label><input className="input" value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/></div>
          <div className="field"><label>Email</label><input type="email" className="input" value={form.email} onChange={e=>setForm({...form,email:e.target.value})}/></div>
          <div className="field"><label>Role</label><select className="select" value={form.role} onChange={e=>setForm({...form,role:e.target.value})}><option>Super Admin</option><option>Finance</option><option>Media (Kahen)</option><option>Office Admin</option><option>Member</option></select></div>
          <div className="field"><label>Status</label><select className="select" value={form.active? 'Active':'Disabled'} onChange={e=>setForm({...form,active:e.target.value==='Active'})}><option>Active</option><option>Disabled</option></select></div>
        </div>
        <button className="btn btn-primary mt-2">Add User</button>
      </form>
      <table className="table">
        <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th></tr></thead>
        <tbody>{users.map((u,i)=>(<tr key={i}><td>{u.name}</td><td>{u.email}</td><td>{u.role}</td><td><span className={u.active?'badge badge-ok':'badge'}>{u.active?'Active':'Disabled'}</span></td></tr>))}</tbody>
      </table>
    </div>
  )
}
