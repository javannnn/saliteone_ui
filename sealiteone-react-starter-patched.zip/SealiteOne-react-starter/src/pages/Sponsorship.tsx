
export default function Sponsorship() {
  return (
    <div>
      <div className="text-sm text-slate-500 mb-1">Home › Sponsorship</div>
      <h1 className="text-2xl font-extrabold mb-3">Sponsorships</h1>

<div className="flex gap-2 items-center mb-2">
  <a className="btn btn-primary" href="#">New Sponsorship</a>
</div>
<table className="table">
  <thead><tr><th>Member</th><th>Frequency</th><th>Last Sponsored</th><th>Status</th></tr></thead>
  <tbody><tr><td>John Doe</td><td>Monthly</td><td>2025-08-01</td><td><span className="badge badge-ok">Approved</span></td></tr></tbody>
</table>

    </div>
  )
}
