
export default function Services() {
  return (
    <div>
      <div className="text-sm text-slate-500 mb-1">Home › Services</div>
      <h1 className="text-2xl font-extrabold mb-3">Service Bookings</h1>

<div className="flex gap-2 items-center mb-2">
  <a className="btn btn-primary" href="/service-booking">Book Service</a>
  <div className="flex-1" />
  <select className="select"><option>Type</option><option>Baptism</option><option>Memorial (Simple)</option><option>Memorial (Full)</option><option>Wedding</option></select>
  <input className="input" placeholder="Member name"/>
</div>
<table className="table">
  <thead><tr><th>Date</th><th>Member</th><th>Service</th><th>Status</th><th>Amount</th></tr></thead>
  <tbody><tr><td>2025-09-10</td><td>John Doe</td><td>Baptism</td><td><span className="badge">Scheduled</span></td><td>$150</td></tr></tbody>
</table>

    </div>
  )
}
