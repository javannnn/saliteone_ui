
export default function AbenetSchool() {
  return (
    <div>
      <div className="text-sm text-slate-500 mb-1">Home › Programs › Abenet School</div>
      <h1 className="text-2xl font-extrabold mb-3">Abenet School — Enrollments</h1>

<div className="flex gap-2 items-center mb-2">
  <a className="btn btn-primary" href="/enrollment">New Enrollment</a>
  <div className="flex-1" />
  <select className="select"><option>Track</option><option>Alphabet</option><option>Reading</option><option>For Deacons</option></select>
  <input className="input" placeholder="Person name"/>
</div>
<table className="table">
  <thead><tr><th>Name</th><th>Track</th><th>Start Date</th><th>Monthly Fee</th><th>Last Payment</th></tr></thead>
  <tbody><tr><td>Sarah Tesfa</td><td>Reading</td><td>2025-06-01</td><td>$25</td><td>2025-08-01</td></tr></tbody>
</table>

    </div>
  )
}
