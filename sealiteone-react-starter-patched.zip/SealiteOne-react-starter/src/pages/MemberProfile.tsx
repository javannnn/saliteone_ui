
import { Link, useParams } from 'react-router-dom'
import { Card } from '@/components/Card'

export default function MemberProfile(){
  const { id } = useParams()
  return (
    <div>
      <div className="text-sm text-slate-500 mb-1">Home › Members › #{id}</div>
      <h1 className="text-2xl font-extrabold mb-3">John Doe <span className="badge badge-ok">Active</span></h1>
      <div className="grid md:grid-cols-3 gap-3">
        <Card title="Identity">
          <div className="text-slate-500 text-sm mb-1">Username: john.doe</div>
          <div>Gender: M</div>
          <div>Baptismal Name: Yohannes</div>
          <div>Father Confessor: Fr. Mark</div>
          <div>Marital Status: Married</div>
        </Card>
        <Card title="Contact">
          <div>Email: john@example.com</div>
          <div>Phone: (555) 555-5555</div>
          <div>Address: 123 St, City, Province</div>
        </Card>
        <Card title="Quick Actions">
          <div className="flex gap-2">
            <Link className="btn" to="/invoice-new">Create Invoice</Link>
            <Link className="btn" to="/service-booking">Book Service</Link>
            <Link className="btn" to="/enrollment">Enroll in Program</Link>
          </div>
        </Card>
      </div>
      <div className="grid md:grid-cols-3 gap-3 mt-3">
        <Card title="Family">
          <table className="table"><tbody>
            <tr><td>Spouse</td><td>Jane Doe</td><td>jane@example.com</td></tr>
            <tr><td>Child</td><td>Michael Doe</td><td>DOB: 2010-05-12</td></tr>
          </tbody></table>
        </Card>
        <Card title="Membership">
          <div>Plan: Monthly Contribution</div>
          <div>Last 6 months: Paid</div>
          <div className="mt-2"><Link className="btn" to="/inbox">Mark for Prescreen</Link></div>
        </Card>
        <Card title="Giving">
          <table className="table">
            <thead><tr><th>Date</th><th>Type</th><th>Amount</th><th>Receipt</th></tr></thead>
            <tbody><tr><td>2025-08-01</td><td>Tithe</td><td>$120.00</td><td><a href="#">Download</a></td></tr></tbody>
          </table>
        </Card>
      </div>
    </div>
  )
}
