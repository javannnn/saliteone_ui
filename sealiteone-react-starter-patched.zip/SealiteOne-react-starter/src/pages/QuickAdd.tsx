
export default function QuickAdd() {
  return (
    <div>
      <div className="text-sm text-slate-500 mb-1">Home › Quick Add</div>
      <h1 className="text-2xl font-extrabold mb-3">Quick Add</h1>

<div className="grid md:grid-cols-4 gap-3">
  <div className="card"><h3 className="font-semibold mb-2">Add Member</h3><a className="btn" href="/members/new">Open</a></div>
  <div className="card"><h3 className="font-semibold mb-2">Create Invoice</h3><a className="btn" href="/invoice-new">Open</a></div>
  <div className="card"><h3 className="font-semibold mb-2">Book Service</h3><a className="btn" href="/service-booking">Open</a></div>
  <div className="card"><h3 className="font-semibold mb-2">Enroll in Program</h3><a className="btn" href="/enrollment">Open</a></div>
</div>

    </div>
  )
}
