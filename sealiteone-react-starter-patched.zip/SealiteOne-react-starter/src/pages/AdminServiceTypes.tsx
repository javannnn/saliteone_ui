
import { useState } from 'react'
type Row = { name:string; category:'Baptism'|'Memorial'|'Wedding'|'Donation'|'Other'; fee:number }
export default function AdminServiceTypes(){
  const [rows,setRows] = useState<Row[]>([{ name:'Baptism', category:'Baptism', fee:150 },{ name:'Memorial - Simple (Sunday)', category:'Memorial', fee:100 }])
  const [form,setForm] = useState<Row>({ name:'', category:'Other', fee:0 })
  return (
    <div>
      <div className="text-sm text-slate-500 mb-1">Home › Admin › Service Types</div>
      <h1 className="text-2xl font-extrabold mb-3">Service Types</h1>
      <div className="card mb-3">
        <div className="grid md:grid-cols-3 gap-3">
          <div className="field"><label>Name</label><input className="input" value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/></div>
          <div className="field"><label>Category</label><select className="select" value={form.category} onChange={e=>setForm({...form,category:e.target.value as any})}><option>Baptism</option><option>Memorial</option><option>Wedding</option><option>Donation</option><option>Other</option></select></div>
          <div className="field"><label>Base Fee</label><input type="number" className="input" value={form.fee} onChange={e=>setForm({...form,fee:parseFloat(e.target.value) || 0})}/></div>
        </div>
        <button className="btn btn-primary" onClick={()=>{ if(form.name) setRows([...rows,form]); setForm({ name:'', category:'Other', fee:0 }) }}>Add</button>
      </div>
      <table className="table"><thead><tr><th>Name</th><th>Category</th><th>Base Fee</th></tr></thead><tbody>{rows.map((r,i)=>(<tr key={i}><td>{r.name}</td><td>{r.category}</td><td>${r.fee.toFixed(2)}</td></tr>))}</tbody></table>
    </div>
  )
}
