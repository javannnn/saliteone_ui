
import { useState } from 'react'
type T = { name:string; subject:string; body:string }
export default function AdminEmailTemplates(){
  const [rows,setRows] = useState<T[]>([
    { name:'Membership Prescreen', subject:'Membership Prescreen Required', body:'Dear {{name}}, your membership is ready for prescreen.' },
    { name:'Media Post Approved', subject:'Your post has been approved', body:'Your {{type}} post "{{title}}" is approved.' },
  ])
  const [form,setForm] = useState<T>({ name:'', subject:'', body:'' })
  return (
    <div>
      <div className="text-sm text-slate-500 mb-1">Home › Admin › Email Templates</div>
      <h1 className="text-2xl font-extrabold mb-3">Email Templates</h1>
      <div className="card mb-3">
        <div className="field"><label>Name</label><input className="input" value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/></div>
        <div className="field"><label>Subject</label><input className="input" value={form.subject} onChange={e=>setForm({...form,subject:e.target.value})}/></div>
        <div className="field"><label>Body</label><textarea className="input" rows={6} value={form.body} onChange={e=>setForm({...form,body:e.target.value})}></textarea></div>
        <button className="btn btn-primary" onClick={()=>{ if(form.name) setRows([...rows,form]); setForm({ name:'', subject:'', body:'' }) }}>Add Template</button>
      </div>
      <table className="table"><thead><tr><th>Name</th><th>Subject</th></tr></thead><tbody>{rows.map((r,i)=>(<tr key={i}><td>{r.name}</td><td>{r.subject}</td></tr>))}</tbody></table>
    </div>
  )
}
