
export default function Settlement() {
  return (
    <div>
      <div className="text-sm text-slate-500 mb-1">Home › Settlement</div>
      <h1 className="text-2xl font-extrabold mb-3">Newcomer Settlement</h1>

<div className="flex mb-2"><a className="btn btn-primary" href="#">New Case</a></div>
<table className="table">
  <thead><tr><th>Full Name</th><th>Family Members</th><th>Arrival</th><th>Sponsor</th><th>Country</th><th>Temp Address</th></tr></thead>
  <tbody><tr><td>Abel Mekonnen</td><td>4</td><td>2025-07-22</td><td>John Doe</td><td>Ethiopia</td><td>123 King St</td></tr></tbody>
</table>

    </div>
  )
}
