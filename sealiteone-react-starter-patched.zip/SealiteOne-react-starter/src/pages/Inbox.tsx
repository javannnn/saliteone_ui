
export default function Inbox() {
  return (
    <div>
      <div className="text-sm text-slate-500 mb-1">Home › Inbox</div>
      <h1 className="text-2xl font-extrabold mb-3">Approvals & Notifications</h1>

<table className="table">
  <thead><tr><th>Type</th><th>Who</th><th>Summary</th><th>Created</th><th></th></tr></thead>
  <tbody>
    <tr><td>Membership Prescreen</td><td>Mary Smith</td><td>6 months paid — review</td><td>Today</td><td><a href="#">Approve</a> · <a href="#">Reject</a></td></tr>
    <tr><td>Media Post</td><td>Fr. Mark</td><td>Mezmur: Psalm 23</td><td>Yesterday</td><td><a href="#">Approve</a> · <a href="#">Reject</a></td></tr>
  </tbody>
</table>

    </div>
  )
}
