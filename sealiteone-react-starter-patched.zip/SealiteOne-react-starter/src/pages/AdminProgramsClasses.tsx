
import { useState } from 'react'
type Row = { program:'Sunday School'|'Abenet School'; classOrTrack:string; monthlyFee:number }
export default function AdminProgramsClasses(){
  const [rows,setRows] = useState<Row[]>([
    { program:'Sunday School', classOrTrack:'Child — Level 1', monthlyFee:25 },
    { program:'Abenet School', classOrTrack:'Reading', monthlyFee:25 },
  ])
  const [form,setForm] = useState<Row>({ program:'Sunday School', classOrTrack:'', monthlyFee:25 })
  return (
    <div>
      <div className="text-sm text-slate-500 mb-1">Home › Admin › Programs & Classes</div>
      <h1 className="text-2xl font-extrabold mb-3">Programs & Classes</h1>
      <div className="card mb-3">
        <div className="grid md:grid-cols-3 gap-3">
          <div className="field"><label>Program</label><select className="select" value={form.program} onChange={e=>setForm({...form,program:e.target.value as any})}><option>Sunday School</option><option>Abenet School</option></select></div>
          <div className="field"><label>Class / Track</label><input className="input" value={form.classOrTrack} onChange={e=>setForm({...form,classOrTrack:e.target.value})}/></div>
          <div className="field"><label>Monthly Fee</label><input type="number" className="input" value={form.monthlyFee} onChange={e=>setForm({...form,monthlyFee:parseFloat(e.target.value)||0})}/></div>
        </div>
        <button className="btn btn-primary" onClick={()=>{ if(form.classOrTrack) setRows([...rows,form]); setForm({ program:'Sunday School', classOrTrack:'', monthlyFee:25 }) }}>Add</button>
      </div>
      <table className="table"><thead><tr><th>Program</th><th>Class/Track</th><th>Monthly Fee</th></tr></thead><tbody>{rows.map((r,i)=>(<tr key={i}><td>{r.program}</td><td>{r.classOrTrack}</td><td>${r.monthlyFee.toFixed(2)}</td></tr>))}</tbody></table>
    </div>
  )
}
