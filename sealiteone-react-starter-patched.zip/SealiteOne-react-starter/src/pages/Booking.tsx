
export default function Booking() {
  return (
    <div>
      <div className="text-sm text-slate-500 mb-1">Home › Services › Book Service</div>
      <h1 className="text-2xl font-extrabold mb-3">Book a Service</h1>

<div className="grid md:grid-cols-2 gap-3">
  <div className="card">
    <div className="field"><label>Member</label><input className="input" placeholder="Search member"/></div>
    <div className="field"><label>Service Type</label><select className="select"><option>Baptism</option><option>Memorial - Simple (Sunday)</option><option>Memorial - Full (Sunday)</option><option>Memorial - Full (Private)</option><option>Wedding</option><option>Other</option></select></div>
    <div className="field"><label>Date</label><input type="date" className="input"/></div>
    <div className="field"><label>Notes</label><textarea className="input" rows={4}></textarea></div>
    <div className="mt-2"><a className="btn btn-primary" href="/services">Create Booking & Invoice</a></div>
  </div>
  <div className="card"><h3 className="font-semibold mb-2">Summary</h3><div className="text-slate-500 text-sm">Base price will auto-populate from Service Catalog.</div></div>
</div>

    </div>
  )
}
