
export default function SundaySchool() {
  return (
    <div>
      <div className="text-sm text-slate-500 mb-1">Home › Programs › Sunday School</div>
      <h1 className="text-2xl font-extrabold mb-3">Sunday School — Enrollments</h1>

<div className="flex gap-2 items-center mb-2">
  <a className="btn btn-primary" href="/enrollment">New Enrollment</a>
  <div className="flex-1" />
  <select className="select"><option>Class</option><option>Child</option><option>Youth</option><option>Adult</option></select>
  <input className="input" placeholder="Person name"/>
</div>
<table className="table">
  <thead><tr><th>Name</th><th>Type</th><th>Class</th><th>Start Date</th><th>Last Payment</th></tr></thead>
  <tbody><tr><td>Michael Doe</td><td>Child</td><td>Level 2</td><td>2025-07-01</td><td>2025-08-01</td></tr></tbody>
</table>

    </div>
  )
}
