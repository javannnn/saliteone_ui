
import { Card } from '@/components/Card'

export default function Dashboard(){
  return (
    <div>
      <div className="text-sm text-slate-500 mb-1">Home</div>
      <h1 className="text-2xl font-extrabold mb-3">Dashboard</h1>
      <div className="grid md:grid-cols-4 gap-3">
        <Card title="Active Members"><div className="text-3xl font-extrabold">1,248</div><div className="text-slate-500 text-sm">+12 this month</div></Card>
        <Card title="Overdue Invoices"><div className="text-3xl font-extrabold">34</div><div className="badge badge-warn mt-1">Action needed</div></Card>
        <Card title="Upcoming Services"><div className="text-3xl font-extrabold">9</div><div className="text-slate-500 text-sm">Next: Baptism (Sun)</div></Card>
        <Card title="Recent Donations"><div className="text-3xl font-extrabold">$4,820</div><div className="text-slate-500 text-sm">Last 7 days</div></Card>
      </div>
    </div>
  )
}
