
import { useState } from 'react'
export default function AdminPriests(){
  const [priests,setPriests] = useState<string[]>(['Fr. Mark','Fr. Luke'])
  const [name,setName] = useState('')
  return (
    <div>
      <div className="text-sm text-slate-500 mb-1">Home › Admin › Priests</div>
      <h1 className="text-2xl font-extrabold mb-3">Priests (Father of Repentance)</h1>
      <div className="card mb-3">
        <div className="field"><label>Name</label><input className="input" value={name} onChange={e=>setName(e.target.value)} /></div>
        <button className="btn btn-primary" onClick={()=>{ if(name) setPriests([...priests,name]); setName('') }}>Add Priest</button>
      </div>
      <table className="table"><thead><tr><th>Name</th></tr></thead><tbody>{priests.map((p,i)=>(<tr key={i}><td>{p}</td></tr>))}</tbody></table>
    </div>
  )
}
