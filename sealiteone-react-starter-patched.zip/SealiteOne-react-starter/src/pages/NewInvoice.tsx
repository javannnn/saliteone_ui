
export default function NewInvoice() {
  return (
    <div>
      <div className="text-sm text-slate-500 mb-1">Home › Billing › Invoices › New</div>
      <h1 className="text-2xl font-extrabold mb-3">Create Invoice</h1>

<div className="grid md:grid-cols-2 gap-3">
  <div className="card">
    <div className="field"><label>Member</label><input className="input" placeholder="Search member"/></div>
    <div className="field"><label>Line Type</label><select className="select"><option>Membership</option><option>Tithe</option><option>Donation</option><option>Service</option><option>Sunday School</option><option>Abenet School</option><option>Sponsorship</option><option>Other</option></select></div>
    <div className="field"><label>Description</label><input className="input" placeholder="e.g., Monthly Contribution (Aug)"/></div>
    <div className="grid md:grid-cols-3 gap-3">
      <div className="field"><label>Qty</label><input className="input" defaultValue="1"/></div>
      <div className="field"><label>Unit Amount</label><input className="input" defaultValue="120.00"/></div>
      <div className="field"><label>Due Date</label><input type="date" className="input"/></div>
    </div>
    <div><a className="btn btn-primary" href="/invoices">Create Invoice</a></div>
  </div>
  <div className="card"><h3 className="font-semibold mb-2">Summary</h3><div className="text-slate-500 text-sm">Invoices can be emailed with a payment link.</div></div>
</div>

    </div>
  )
}
