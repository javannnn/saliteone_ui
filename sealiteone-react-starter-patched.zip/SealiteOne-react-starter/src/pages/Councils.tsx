
export default function Councils() {
  return (
    <div>
      <div className="text-sm text-slate-500 mb-1">Home › Councils</div>
      <h1 className="text-2xl font-extrabold mb-3">Parish Councils</h1>

<table className="table">
  <thead><tr><th>Office</th><th>Member</th><th>Email</th><th>Phone</th><th>Trainee (From–To)</th></tr></thead>
  <tbody><tr><td>Chairman</td><td>Daniel Y.</td><td>d.y@example.com</td><td>(555) 777-1212</td><td>Sarah T. (2025-06 → 2025-12)</td></tr></tbody>
</table>

    </div>
  )
}
