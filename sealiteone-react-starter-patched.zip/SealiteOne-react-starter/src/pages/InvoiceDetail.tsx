
export default function InvoiceDetail() {
  return (
    <div>
      <div className="text-sm text-slate-500 mb-1">Home › Billing › Invoices › INV-1028</div>
      <h1 className="text-2xl font-extrabold mb-3">Invoice INV-1028</h1>

<span className="badge badge-warn">Overdue</span>
<div className="grid md:grid-cols-2 gap-3 mt-2">
  <div className="card">
    <h3 className="font-semibold mb-2">Lines</h3>
    <table className="table">
      <thead><tr><th>Type</th><th>Description</th><th>Qty</th><th>Unit</th><th>Amount</th></tr></thead>
      <tbody><tr><td>Membership</td><td>Monthly Contribution (Aug)</td><td>1</td><td>$120.00</td><td>$120.00</td></tr></tbody>
    </table>
  </div>
  <div className="card">
    <h3 className="font-semibold mb-2">Actions</h3>
    <div className="flex gap-2 mb-2">
      <a className="btn btn-primary" href="/payments">Record Payment</a>
      <a className="btn" href="#">Send Invoice</a>
    </div>
    <h3 className="font-semibold mb-2">Payments</h3>
    <div className="text-slate-500 text-sm">No payments yet.</div>
  </div>
</div>

    </div>
  )
}
