
export default function Media() {
  return (
    <div>
      <div className="text-sm text-slate-500 mb-1">Home › Media</div>
      <h1 className="text-2xl font-extrabold mb-3">Media Inbox</h1>

<table className="table">
  <thead><tr><th>Requestor</th><th>Type</th><th>Title</th><th>Status</th><th></th></tr></thead>
  <tbody><tr><td>Fr. Mark</td><td>Mezmur</td><td>Psalm 23</td><td><span className="badge">Pending</span></td><td><a href="#">Approve</a> · <a href="#">Reject</a></td></tr></tbody>
</table>
<div className="grid md:grid-cols-3 gap-3 mt-3">
  <div className="card"><h3 className="font-semibold mb-2">Sermons</h3><a className="btn" href="#" href="/media/sermons">Add Sermon</a></div>
  <div className="card"><h3 className="font-semibold mb-2">Resources</h3><a className="btn" href="#" href="/media/resources">Upload Resource</a></div>
  <div className="card"><h3 className="font-semibold mb-2">Website Posts</h3><a className="btn" href="#" href="/media/posts">New Post</a></div>
</div>

    </div>
  )
}
