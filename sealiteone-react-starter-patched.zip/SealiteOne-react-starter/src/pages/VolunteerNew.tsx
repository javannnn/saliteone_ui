
export default function VolunteerNew(){
  return (
    <div>
      <div className="text-sm text-slate-500 mb-1">Home › Volunteers › Add</div>
      <h1 className="text-2xl font-extrabold mb-3">Add Volunteer</h1>
      <div className="card">
        <div className="grid md:grid-cols-3 gap-3">
          <div className="field"><label>First Name</label><input className="input" /></div>
          <div className="field"><label>Last Name</label><input className="input" /></div>
          <div className="field"><label>Phone</label><input className="input" /></div>
          <div className="field"><label>Group</label><select className="select"><option>Peter</option><option>James</option><option>John</option><option>Andrew</option><option>Philip</option><option>Matthew</option><option>Thomas</option><option>James, son of Alpheus</option><option>Bartholomew</option><option>Judas Thaddeus</option><option>Simon Zelotes</option></select></div>
          <div className="field"><label>Service Type</label><select className="select"><option>General Service</option><option>Holiday</option></select></div>
          <div className="field"><label>Month</label><input type="month" className="input" /></div>
        </div>
        <div className="mt-2"><a className="btn btn-primary" href="/volunteers">Save Volunteer</a></div>
      </div>
    </div>
  )
}
