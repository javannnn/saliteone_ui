
import { useState } from 'react'
export default function AdminPaymentMethods(){
  const [methods,setMethods] = useState<string[]>(['Cash','Debit','Credit','e-transfer','Cheque'])
  const [val,setVal] = useState('')
  return (
    <div>
      <div className="text-sm text-slate-500 mb-1">Home › Admin › Payment Methods</div>
      <h1 className="text-2xl font-extrabold mb-3">Payment Methods</h1>
      <div className="card mb-3">
        <div className="field"><label>Method</label><input className="input" value={val} onChange={e=>setVal(e.target.value)}/></div>
        <button className="btn btn-primary" onClick={()=>{ if(val) setMethods([...methods,val]); setVal('') }}>Add Method</button>
      </div>
      <table className="table"><thead><tr><th>Method</th></tr></thead><tbody>{methods.map((m,i)=>(<tr key={i}><td>{m}</td></tr>))}</tbody></table>
    </div>
  )
}
