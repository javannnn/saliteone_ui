
export default function Volunteers() {
  return (
    <div>
      <div className="text-sm text-slate-500 mb-1">Home › Volunteers</div>
      <h1 className="text-2xl font-extrabold mb-3">Volunteer Groups</h1>
<div className="mb-2"><a className="btn btn-primary" href="/volunteers/new">Add Volunteer</a></div>

<table className="table">
  <thead><tr><th>Group</th><th>Team Lead</th><th>Phone</th><th>Assignments (Month)</th></tr></thead>
  <tbody>
    <tr><td>Peter</td><td>Samuel K.</td><td>(555) 901-2233</td><td>Sept: General Service</td></tr>
    <tr><td>James</td><td>Rebecca T.</td><td>(555) 671-8844</td><td>Oct: Holiday</td></tr>
  </tbody>
</table>

    </div>
  )
}
