
export default function Payments() {
  return (
    <div>
      <div className="text-sm text-slate-500 mb-1">Home › Billing › Payments</div>
      <h1 className="text-2xl font-extrabold mb-3">Payments</h1>

<table className="table">
  <thead><tr><th>Date</th><th>Invoice</th><th>Member</th><th>Method</th><th>Amount</th></tr></thead>
  <tbody><tr><td>2025-08-03</td><td>INV-1025</td><td>Mary Smith</td><td>Credit</td><td>$75.00</td></tr></tbody>
</table>

    </div>
  )
}
