
import { useState } from 'react'
type Row = { type:'Mezmur'|'Lesson'|'Announcement'; title:string; content:string; status:'Pending'|'Approved'|'Rejected' }
export default function MediaPosts(){
  const [rows,setRows] = useState<Row[]>([
    { type:'Mezmur', title:'Psalm 23', content:'The Lord is my shepherd...', status:'Pending' }
  ])
  const [form,setForm] = useState<Row>({ type:'Mezmur', title:'', content:'', status:'Pending' })
  return (
    <div>
      <div className="text-sm text-slate-500 mb-1">Home › Media › Website Posts</div>
      <h1 className="text-2xl font-extrabold mb-3">Website Posts</h1>
      <div className="card mb-3">
        <div className="grid md:grid-cols-3 gap-3">
          <div className="field"><label>Type</label><select className="select" value={form.type} onChange={e=>setForm({...form,type:e.target.value as any})}><option>Mezmur</option><option>Lesson</option><option>Announcement</option></select></div>
          <div className="field"><label>Title</label><input className="input" value={form.title} onChange={e=>setForm({...form,title:e.target.value})}/></div>
          <div className="field"><label>Status</label><select className="select" value={form.status} onChange={e=>setForm({...form,status:e.target.value as any})}><option>Pending</option><option>Approved</option><option>Rejected</option></select></div>
        </div>
        <div className="field"><label>Content</label><textarea className="input" rows={6} value={form.content} onChange={e=>setForm({...form,content:e.target.value})}></textarea></div>
        <button className="btn btn-primary" onClick={()=>{ if(form.title) setRows([...rows,form]); setForm({ type:'Mezmur', title:'', content:'', status:'Pending' }) }}>Add Post</button>
      </div>
      <table className="table"><thead><tr><th>Type</th><th>Title</th><th>Status</th></tr></thead><tbody>{rows.map((r,i)=>(<tr key={i}><td>{r.type}</td><td>{r.title}</td><td><span className="badge">{r.status}</span></td></tr>))}</tbody></table>
    </div>
  )
}
