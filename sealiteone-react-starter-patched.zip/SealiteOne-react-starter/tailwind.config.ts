
import type { Config } from 'tailwindcss'
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: { brand: { DEFAULT:'#2563eb', 600:'#2563eb', 700:'#1d4ed8' } },
      boxShadow: { soft: '0 1px 2px rgba(0,0,0,.04), 0 8px 24px rgba(2,6,23,.06)' },
      borderRadius: { '2xl': '1rem' }
    }
  },
  plugins: [],
} satisfies Config
